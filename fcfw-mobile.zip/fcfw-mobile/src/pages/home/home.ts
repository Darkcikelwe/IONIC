import { IonicPage, AlertController, Platform } from 'ionic-angular';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { NativeAudio } from '@ionic-native/native-audio';

@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  
  // private isAndroid: boolean = false;

  constructor(
    private nativeAudio: NativeAudio,
    public navCtrl: NavController,
    public alertCtrl: AlertController,
    public platform: Platform
  ) {

  }


  setSound() {
    if (this.platform.is('android')) {
      this.nativeAudio.preloadSimple('uniqueId1', 'assets/sounds/__alert4.mp3');
      this.nativeAudio.play('uniqueId1');
    }
  }
}
