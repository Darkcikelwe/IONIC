import { BaseService } from './../../services/base-service';
// Modulo de acesso
// Utilizado para conexão ao banco Oracle da empresa
import { IonicPage } from 'ionic-angular';
import { Component, ViewChild, ElementRef,OnInit } from '@angular/core';
import { NavController, MenuController, Keyboard, Platform } from 'ionic-angular';
import { BaseCommon } from './../../commons/base-common';
import { AuthProvider } from './../../services/auth-service';
import { AppVersion } from '@ionic-native/app-version';
import { Network } from '@ionic-native/network';
import { Http } from '@angular/http';

// by Ryuge 14/02/2019
import { ENV} from '@app/env';
// by Ryuge 28/01/2019
import { AppConfig,getHTTP } from '../../config/app.config';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage implements OnInit {


  ngOnInit(){
    console.log('environment.message');
    console.log(getHTTP());
  }  

  public appVer: string = '';
  public versao: string = '';
  public isLoggedIn: boolean;
  public foto;
  public usuarioLogado;
  public noPhoto: boolean = false;

  // loginData = { login: 'R6543MRM', senha: 'japa1966' };
  loginData = { login: '', senha: '' };
  data: any;

  public ionScroll;
  @ViewChild('scrollMe') private myScrollContainer: ElementRef;

  constructor(
    public http: Http,
    public appConfig: AppConfig,
    public navCtrl: NavController,
    public authService: AuthProvider,
    public baseCommon: BaseCommon,
    private menu: MenuController,
    public Keyb: Keyboard,
    public platform: Platform,
    private appVersion: AppVersion,
    public network: Network,
    public baseService: BaseService
    
  ) {

   
    // console.log('process.env.IONIC_ENV');
    // console.log(envVariables.ionicEnvName);

    console.log('process.env.IONIC_ENV');
    console.log(ENV.mode);

    if (ENV.mode == 'Production') {
      this.loginData.login = '';
      this.loginData.senha = '';
    } else {
      this.loginData.login = 'R6543MRM';
      this.loginData.senha = 'japa1966';
    }

    if (this.platform.is('ios') || this.platform.is('android')) {
      this.versao = '';
    }

    if (localStorage.getItem("token")) {
      this.isLoggedIn = JSON.parse(localStorage.getItem("isLoggedIn"));
      this.foto = localStorage.getItem("foto");
      this.usuarioLogado = localStorage.getItem("nome");
      this.loginData.login = localStorage.getItem("login");

      if (localStorage.getItem("foto") === 'null') {
        this.noPhoto = true;
      }
    }

  }


  setHeightUnic(div) {
    div[0].style.height = "auto";
  }

  setHeight(div, valor) {
    for (var i = 0; i < div.length; i++) {
      div[i].style.height = valor + "vh";
    }
  }

  resizeElementHeight(tipo: any) {
    var element = document.getElementsByClassName("loginFormSection");

    // Loop over matching divs
    for (var i = 0; i < element.length; i++) {
      var ele = element[i];
    }
    if (tipo == 'LOCK') {
      this.setHeight(element, 100);
    } else {
      this.setHeightUnic(element);
    }

  }


  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  scrollToBottom(): void {
    this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
  }

  ionViewDidLeave() {
    this.menu.swipeEnable(true);
  }

  ionViewDidLoad(){
    this.getVer();
  }

  async getVer(){
    await this.authService.getVerProduction();
    console.log('this.appVerProd');
    console.log(this.baseCommon.ApplicationVersion);

    if (this.platform.is('ios') || this.platform.is('android')) {
      this.getVerCodePro(this.baseCommon.ApplicationVersion);
    }

  }

  ionViewDidEnter() {
    this.menu.swipeEnable(false);
  }

  showVersion() {
    if (this.platform.is('ios') || this.platform.is('android')) {
      this.getVersionCode();
    }
  }

  async getVersionCode() {
    let versionCode = await this.appVersion.getVersionCode();
    let versionNumber: string = await this.appVersion.getVersionNumber();

    let value = versionCode.toString();
    value = value.replace(/^(\d{1})(\d)/, '$1.$2');

    let value2 = versionNumber.toString();

    value = 'Versão: ' + value2 + '<br/> Version Code: ' + value;

    this.baseCommon.showAlert2(this.baseCommon.ApplicationName, value);

    console.log(versionCode);
  }

  async getVerCodePro(ver) {
    let versionCode = await this.appVersion.getVersionCode();
    let versionNumber: string = await this.appVersion.getVersionNumber();

    let value = versionCode.toString();
    value = value.replace(/^(\d{1})(\d)/, '$1.$2');

    let value2 = versionNumber.toString();

    value = 'Versão: ' + value2 + '<br/> Version Code: ' + value;

    if(ver != versionCode){
      this.baseCommon.showAlert2( this.baseCommon.ApplicationName, 'Versão está desatualizada!');
    }
    

    console.log(versionCode);
  }

  doLogin() {

    if (this.platform.is('ios') || this.platform.is('android')) {

      this.baseCommon.showLoader();
      this.authService.login(this.loginData.login.toUpperCase(), this.loginData.senha).then((result) => {
        this.baseCommon.loading.dismiss();
        this.data = result;

        if (this.data.status == 'OK') {
          this.baseCommon.showAlert2(this.data.json().title, this.data.json().detail);
        } else {

          localStorage.setItem('token', this.data.authorization);
          localStorage.setItem('login', this.loginData.login);
          localStorage.setItem('foto', this.data.foto);
          localStorage.setItem('empresa', this.data.empresa.id);
          localStorage.setItem('nome', this.data.nomeDisplay);
          localStorage.setItem('isLoggedIn', 'true');
          
          this.authService.menuAcesso = 'Logout';

          if (localStorage.getItem("foto") === 'null') {
            this.noPhoto = true;
          }

          if (this.platform.is('ios') || this.platform.is('android')) {

            this.baseCommon.showAlert2('VERSÃO', this.appVer);
          }
      
          this.navCtrl.setRoot("HomePage");

        }


      }, (err) => {
        this.isLoggedIn = false;
        this.baseCommon.loading.dismiss();
        this.loginData.senha = '';

        if (err.json().tittle != "" && err.json().detail != "") {
          this.baseCommon.showAlert2(err.json().title, err.json().detail);
        } else {
          this.baseCommon.showAlert2("Ops!", err);
        }
      });

    } else {

      this.baseCommon.showLoader();
      this.authService.login(this.loginData.login.toUpperCase(), this.loginData.senha).then((result) => {
        this.baseCommon.loading.dismiss();
        this.data = result;

        if (this.data.status == 'OK') {
          this.baseCommon.showAlert2(this.data.json().title, this.data.json().detail);
        } else {

          localStorage.setItem('token', this.data.authorization);
          localStorage.setItem('login', this.loginData.login);
          localStorage.setItem('foto', this.data.foto);
          localStorage.setItem('empresa', this.data.empresa.id);
          localStorage.setItem('nome', this.data.nomeDisplay);
          localStorage.setItem('isLoggedIn', 'true');

          this.authService.menuAcesso = 'Logout';

          if (localStorage.getItem("foto") === 'null') {
            this.noPhoto = true;
          }

          // let status: boolean = true;
          this.navCtrl.setRoot("HomePage");
          // this.navCtrl.push('HomePage');

        }


      }, (err) => {
        this.isLoggedIn = false;
        this.baseCommon.loading.dismiss();
        this.loginData.senha = '';
        if (err.json().tittle && err.json().detail) {
          this.baseCommon.showAlert2(err.json().title, err.json().detail);
        } else {
          this.baseCommon.showAlert2("Ops!", err);
        }
      });

    }
  }


  logout() {
    this.isLoggedIn = false;
    this.authService.menuAcesso = 'Login';

    if (localStorage.getItem("token")) {
      localStorage.clear();
    }
    this.navCtrl.setRoot("LoginPage");
  }

 

}





