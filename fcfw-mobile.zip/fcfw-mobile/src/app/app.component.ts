import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { LoginPage } from '../pages/login/login';
// import { AndroidFullScreen } from '@ionic-native/android-full-screen';


@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  rootPage: any = LoginPage;

  constructor(
    platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen

  ) {
    platform.ready().then(() => {
      statusBar.styleDefault();

      // if(platform.is("android")){
      //   //Torna FullScreen em android, usada para prevenir erros envolvendo o teclado do android
      //   this.androidFullScreen.isImmersiveModeSupported().then(()=>{
      //     this.androidFullScreen.immersiveMode();
      //   }).catch(error =>{
      //     console.error(error);
      //   })
      // }
    
      splashScreen.hide();
    });
  }
}

