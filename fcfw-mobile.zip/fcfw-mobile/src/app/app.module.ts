import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { AppVersion } from '@ionic-native/app-version';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { LoginPage } from '../pages/login/login';
import { MyApp } from './app.component';
import { Network } from '@ionic-native/network';
import { NavigationBar } from '@ionic-native/navigation-bar';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { HttpModule } from '@angular/http';
import { ENV } from '@app/env';

//----Imports dos providers e serviços internos
import { BaseCommon } from '../commons/base-common';
import { AuthProvider } from '../services/auth-service';
import { BaseService } from '../services/base-service';
import { LoginPageModule } from '../pages/login/login.module';
import { AppConfig,getHTTP } from '../config/app.config';
import { NativeAudio } from '@ionic-native/native-audio';

@NgModule({
  declarations: [
    MyApp,
  ],
  imports: [
    BrowserModule,HttpModule,
    IonicModule.forRoot(MyApp, {
      scrollPadding: false,
      scrollAssist: true,
      autoFocusAssist: false
    }),
    LoginPageModule,
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,
  ],
  providers: [
    StatusBar, SplashScreen, AuthProvider, AndroidFullScreen,
    BaseCommon, BaseService, Network, NavigationBar, AppConfig,
    AppVersion,NativeAudio,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
