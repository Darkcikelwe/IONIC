import { Injectable } from '@angular/core';
import { AlertController, LoadingController, ToastController } from 'ionic-angular';

@Injectable()
export class BaseCommon {
  constructor(
    private toastCtrl: ToastController,
    public loadingCtrl: LoadingController,
    private alertCtrl: AlertController,
  ) { }

  public ApplicationName: string = 'FCFW-Modelo';  
  public ApplicationVersion: string;  

  public loading: any;
  public emailRegex = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;

  //formata de forma generica os campos
  public currency(n) {
    n = parseFloat(n);
    return isNaN(n) ? false : n.toFixed(2);
  }

  public getFormattedPrice(price: number) {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(price);
  }

  public captilizeString(text) {
    return (!!text) ? text.charAt(0).toUpperCase() + text.substr(1).toLowerCase() : '';
  }

  public isNumber(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }

  public validCPF(cpf: string): boolean {
    if (cpf == null) {
      return false;
    }
    if (cpf.length != 11) {
      return false;
    }
    if ((cpf == '00000000000') || (cpf == '11111111111') || (cpf == '22222222222') || (cpf == '33333333333')
      || (cpf == '44444444444') || (cpf == '55555555555') || (cpf == '66666666666') || (cpf == '77777777777')
      || (cpf == '88888888888') || (cpf == '99999999999')) {
      return false;
    }
    let numero: number = 0;
    let caracter: string = '';
    let numeros: string = '0123456789';
    let j: number = 10;
    let somatorio: number = 0;
    let resto: number = 0;
    let digito1: number = 0;
    let digito2: number = 0;
    let cpfAux: string = '';
    cpfAux = cpf.substring(0, 9);
    for (let i: number = 0; i < 9; i++) {
      caracter = cpfAux.charAt(i);
      if (numeros.search(caracter) == -1) {
        return false;
      }
      numero = Number(caracter);
      somatorio = somatorio + (numero * j);
      j--;
    }
    resto = somatorio % 11;
    digito1 = 11 - resto;
    if (digito1 > 9) {
      digito1 = 0;
    }
    j = 11;
    somatorio = 0;
    cpfAux = cpfAux + digito1;
    for (let i: number = 0; i < 10; i++) {
      caracter = cpfAux.charAt(i);
      numero = Number(caracter);
      somatorio = somatorio + (numero * j);
      j--;
    }
    resto = somatorio % 11;
    digito2 = 11 - resto;
    if (digito2 > 9) {
      digito2 = 0;
    }
    cpfAux = cpfAux + digito2;
    if (cpf != cpfAux) {
      return false;
    }
    else {
      return true;
    }
  }

  validaCodigoEndereco(codigo){
    if(codigo.indexOf(":") == -1){
      return false;
    }
    return codigo.split(":");
  }

  validaCodigoPedidoWMS(codigo) {
    if (codigo.indexOf("-") == -1) {
      return false;
    }
    return codigo.split("-");
  }

  public validarCNPJ(cnpj): boolean {

    cnpj = cnpj.replace(/[^\d]+/g, '');

    if (cnpj == '') {
      return false;
    }

    if (cnpj.length != 14) {
      return false;
    }

    // Elimina CNPJs invalidos conhecidos
    if (cnpj == '00000000000000' || cnpj == '11111111111111' || cnpj == '22222222222222' ||
      cnpj == '33333333333333' || cnpj == '44444444444444' || cnpj == '55555555555555' ||
      cnpj == '66666666666666' || cnpj == '77777777777777' || cnpj == '88888888888888' ||
      cnpj == '99999999999999') {
      return false;
    }
    // Valida DVs
    let tamanho = cnpj.length - 2;
    let numeros = cnpj.substring(0, tamanho);
    let digitos = cnpj.substring(tamanho);
    let soma = 0;
    let pos = tamanho - 7;
    for (let i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
        pos = 9;
    }
    let resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(0))
      return false;

    tamanho = tamanho + 1;
    numeros = cnpj.substring(0, tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (let i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
        pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(1))
      return false;

    return true;
  }

  validateEAN13(scan){
    var regexp = /^\d{13,16}$/
    return regexp.test(scan);
  }


  validateEmail(email) {
    return /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(String(email).toLowerCase());
  }

  validarNumeroCelular(celular) {
    // /^\(?\d{2}\)?[9][\s\.]?[7-9]{1}\d{3}-?\d{4}$/
    var regexp = /(^\(11\) 9[5-9]\d{3}-\d{4}|\((?:1([2-9]|[2-9]\d)\)) 9[5-9]\d{3}-\d{4})|(^\([2-9][1-9]\) 9[6-9]\d{3}-\d{4})$/
    return regexp.test(celular);
  }

  validateScan(scan){
    var regexp = /^([-!"#$%&'()*+,.\/:;<=>?@[\\\]_`{|}~|a-z|A-Z|\d]+) *(P\d+|\d{13,16})$/

    return regexp.test(scan);
  }

  // validateEndereco(scan){
  //   var regexp = 
  // }

  codeScan(scan){
    var regexp = /(P\d+|\d{13,16})$/
    return regexp.exec(scan);
  }

  showToastOk(msg) {
    const toast = this.toastCtrl.create({
      message: msg,
      showCloseButton: true,
      closeButtonText: 'Ok'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  showToast(msg) {

    // this.presentAlert(msg);

    let toast = this.toastCtrl.create({
      message: msg,
      duration: 5000,
      position: 'bottom',
      dismissOnPageChange: true
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  showLoader() {
    this.loading = this.loadingCtrl.create({
      spinner: 'ios',
      // content: 'Carregando...',
      // showBackdrop: true,
    });

    this.loading.present();
  }


  showAlert(idPedido, msg) {
    let alert = this.alertCtrl.create({
      title: 'PEDIDO: ' + idPedido,
      subTitle: msg,
      buttons: ['OK'],
      cssClass: 'alertCustomCss'
    });
    alert.present();
  }

  showAlert2(titulo, msg) {
    if(msg != null){
      let alert = this.alertCtrl.create({
        title: titulo,
        subTitle: msg,
        buttons: ['OK']
      });
      alert.present();
    }

  }

  showAlert3(titulo, msg) {
    if(msg != null){
      let alert = this.alertCtrl.create({
        title: titulo,
        subTitle: msg,
        buttons: [
          {
            text: 'ok',
            handler: () => {
              // this.exibeSkeletonLoading = true;
            }
          }          
        ]
        // cssClass: 'alertCustomCss2'
      });
      alert.present();
    }

  }

  isEmptyObject(obj) {
    for (var prop in obj) {
      if (obj.hasOwnProperty(prop)) {
        return false;
      }
    }

    return true;
  }

  presentPrompt(cod) {
    let alert = this.alertCtrl.create({
      title: 'SCANNER',
      inputs: [
        {
          name: 'codScanner',
          placeholder: 'Escanear produto'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Login',
          handler: data => {
            console.log(cod);
          }
        }
      ]
    });
    alert.present();
  }
  // formatação de string
  public formata(value: string, filter: string) {
    value = value.toString();

    if (filter == 'CEP') {
      value = value.replace(/\D/g, '');
      value = value.replace(/^(\d{2})(\d{3})(\d)/, "$1.$2-$3");
      return value;
    }

    if (filter === 'CPFCGC') {

      value = value.toString();

      if (value.length === 11) {
        value = value.replace(/\D/g, ''); //Remove tudo o que não é dígito
        value = value.replace(/(\d{3})(\d)/, '$1.$2'); //Coloca um ponto entre o terceiro e o quarto dígitos
        value = value.replace(/(\d{3})(\d)/, '$1.$2'); //Coloca um ponto entre o terceiro e o quarto dígitos
        //de novo (para o segundo bloco de números)
        value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2'); //Coloca um hífen entre o terceiro e o quarto dígitos
        return value;
      } else {
        value = value.replace(/\D/g, ''); //Remove tudo o que não é dígito
        value = value.replace(/^(\d{2})(\d)/, '$1.$2'); //Coloca ponto entre o segundo e o terceiro dígitos
        value = value.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3'); //Coloca ponto entre o quinto e o sexto dígitos
        value = value.replace(/\.(\d{3})(\d)/, '.$1/$2'); //Coloca uma barra entre o oitavo e o nono dígitos
        value = value.replace(/(\d{4})(\d)/, '$1-$2'); //Coloca um hífen depois do bloco de quatro dígitos
        return value;
      }
    }

    if (filter === 'FONE') {

      if (value.length === 11) {
        value = value.replace(/^(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
      } else {
        value = value.replace(/^(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
      }
      return value;

    }
  }

}
