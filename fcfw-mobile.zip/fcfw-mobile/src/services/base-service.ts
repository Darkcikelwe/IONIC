import { Injectable } from "@angular/core";
import { Headers, Http, RequestOptions } from "@angular/http";
import { Network } from "@ionic-native/network";
import { Platform } from "ionic-angular";
import { BaseCommon } from "./../commons/base-common";

import "rxjs/add/operator/map";

// import * as environment from "./../../environments/environment";
import { CommonServices } from "./../../services/common-services";

// by Ryuge 27/02/2019
// import { AppConfig,API_URL } from '../../config/app.config';
// import { ENV } from '@app/env';

declare var navigator: any;
declare var Connection: any;

@Injectable()
export class BaseService {
  constructor(
    public http: Http,
    public baseCommon: BaseCommon,
    public network: Network,
    public platform: Platform
  ) {}

  public checkNetwork() {
    if (this.platform.is("cordova")) {
      var networkState = navigator.connection.type;

      var states = {};
      states[Connection.UNKNOWN] = "Unknown connection";
      states[Connection.ETHERNET] = "Ethernet connection";
      states[Connection.WIFI] = "WiFi connection";
      states[Connection.CELL_2G] = "Cell 2G connection";
      states[Connection.CELL_3G] = "Cell 3G connection";
      states[Connection.CELL_4G] = "Cell 4G connection";
      states[Connection.CELL] = "Cell generic connection";
      states[Connection.NONE] = "No network connection";

      if (
        // networkState == Connection.UNKNOWN ||
        networkState == Connection.NONE
      ) {
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  // metodo especifio para cadastro cliente
  getNoAlert(parameters: string) {
    if (!this.checkNetwork()) {
      this.baseCommon.showToast("Sem conexão!");
    } else {
      return new Promise((resolve, reject) => {
        let headers = new Headers();
        // headers
        headers.append("x-auth-token", localStorage.getItem("token"));
        let options = new RequestOptions({ headers: headers });
        this.http
          .get(parameters, options)
          .map(result => result.json())
          .subscribe(
            (result: any) => {
              resolve(result);
            },
            error => {
              reject(error);
              try {
                this.baseCommon.loading.dismiss();
              } catch (err) {}
            }
          );
      });
    }
  }

  get(parameters: string) {
    if (!this.checkNetwork()) {
      this.baseCommon.showToast("Sem conexão!");
    } else {
      return new Promise((resolve, reject) => {
        let headers = new Headers();
        // headers
        // headers.append('Cache-Control', 'no-store');
        headers.append("x-auth-token", localStorage.getItem("token"));
        let options = new RequestOptions({ headers: headers });
        this.http
          .get(parameters, options)
          .map(result => result.json())
          .subscribe(
            (result: any) => {
              resolve(result);
            },
            error => {
              // reject(error);
              try {
                this.baseCommon.loading.dismiss();
              } catch (err) {}
              this.handleError(error);
            }
          );
      });
    }
  }

  post(parameters: string, body: {}) {
    if (!this.checkNetwork()) {
      this.baseCommon.showToast("Sem conexão!");
    } else {
      return new Promise((resolve, reject) => {
        let headers = new Headers();
        headers.append("x-auth-token", localStorage.getItem("token"));
        let options = new RequestOptions({ headers: headers });
        this.http
          .post(parameters, body, options)
          .map(result => result.json())
          .subscribe(
            (result: any) => {
              resolve(result);
            },
            error => {
              try {
                this.baseCommon.loading.dismiss();
              } catch (err) {}
              this.handleError(error);
            }
          );
      });
    }
  }

  put(parameters: string, body: {}) {
    if (!this.checkNetwork()) {
      this.baseCommon.showToast("Sem conexão!");
    } else {
      return new Promise((resolve, reject) => {
        let headers = new Headers();
        // headers.append('Cache-Control', 'no-store');
        headers.append("x-auth-token", localStorage.getItem("token"));
        let options = new RequestOptions({ headers: headers });
        this.http.put(parameters, body, options).map(result => result.json()),
          error => {
            this.handleError(error);
          };
      });
    }
  }

  private handleError(error: any) {
    try {
      this.baseCommon.loading.dismiss();
    } catch (err) {}
      this.baseCommon.showAlert3(error.json().title, error.json().detail);      
  }

  delete(url): Promise<void> {
    if (!this.checkNetwork()) {
      this.baseCommon.showToast("Sem conexão!");
    } else {
      let headers = new Headers();
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });

      return this.http
        .post(url, {}, options)
        .toPromise()
        .then(() => null)
        .catch(error => {
          this.baseCommon.showAlert2(
            error.json().title,
            error.json().detail
          );
        });
    }
  }


}
