import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import { BaseService } from './../services/base-service';
import { BaseCommon } from './../commons/base-common';

// by Ryuge 15/02/2019
import { AppConfig,API_URL  } from './../config/app.config';

import { ENV } from '@app/env';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';


@Injectable()
export class AuthProvider {

  // public token: any;
  public menuAcesso: string = 'Login';

  constructor(
    private appConfig: AppConfig,
    public http: Http, 
    private baseCommon: BaseCommon,
    private baseService: BaseService) { }

  login(login: string, senha: string) {

    if (!this.baseService.checkNetwork()) {
      this.baseCommon.loading.dismiss();
      this.baseCommon.showToast('Sem conexão!');
    } else {
      return new Promise((resolve, reject) => {

        let headers = new Headers();

        headers.append('login', login);
        headers.append('senha', senha);

        let options = new RequestOptions({ headers: headers });
        this.http.get(API_URL+ENV.WS_AUTH + 'loginMobile', options).subscribe(res => {
          resolve(res.json());
          console.log(res.json());
        }, (err) => {
          reject(err);
        });

      });
    }
  }

  
  async getVerProduction() {
    var url = 'http://hmlfcimbservices.ferreiracosta.local:8585/WS-Publico/getVersao/2?arquivo=VersaoSFC.exe&tipo=S';    

    await this.baseService.get(url).then(result=>{
      console.log("Teste")
      let res: any = result;
      console.log(res.versao)
      this.baseCommon.ApplicationVersion = res.versao;
    },error=>{
      console.log(error)
    });
  
  }
 
  

}
