import { Environment } from './environment.model';

export const ENV: Environment = {
  mode: 'Production',
  WS_AUTH: 'WS-Authentication/',
  WS_PRODUTO: 'WS-Produto/',
  WS_CRM: 'WS-CRM/',
  WS_VENDAS: 'WS-Vendas/',
  WS_PUBLIC: 'WS-Publico/',
  WS_COMMONS: 'WS-Commons/'
}

