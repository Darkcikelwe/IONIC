import { Injectable } from "@angular/core";
import { Http } from "@angular/http";

// by Ryuge 14/02/2019
import { ENV} from '@app/env';

declare var navigator: any;
declare var Connection: any;

export let API_URL: any;

export function getHTTP() : any {
  return  API_URL;
}

@Injectable()
export class AppConfig {
  // data: Observable<any>;
  posts: any;
  // dados: any;

  // // Json server connection
  private getApiUrl: string = '';

  constructor(
    public http: Http,
    ){
      if (ENV.mode == 'Production') {
        this.getApiUrl = 'http://fcimbservices.ferreiracosta.local:8080/WS-Publico/getUrlService?apl=pv';
        this.getURL();
        getHTTP();
      }else{
         API_URL = 'http://hmlfcimbservices.ferreiracosta.local:8585/';
      }

    //  http://hmlfcimbservices.ferreiracosta.local:8585/WS-Publico/getVersao/2?arquivo=VersaoSFC.exe&tipo=S
    //  Net.showLog('MAIK RYUGE');
    //  Net.downloadJson();          

  }


 public getURL() {
    let apiUrl = this.getApiUrl;
    return new Promise(resolve => {
      this.http.get(apiUrl).subscribe(data => {
        console.log(data);
        let link: any =  data.json();
        API_URL = link.server+'/';
        resolve(data);
      }, err => {
        console.log(err);
      });
    });
  }
 
 
 }

