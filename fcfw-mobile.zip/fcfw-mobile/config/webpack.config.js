// by ryuge 25/09/2018
// $env:APP_ENV="prod" ou $env:APP_ENV="dev"

const chalk = require("chalk");
var path = require('path');
var defaultConfig = require('@ionic/app-scripts/config/webpack.config.js');

var env = process.env.APP_ENV ? process.env.APP_ENV : 'dev';

console.log(chalk.yellow.bgBlack('\nUsing ' + env + ' environment variables.\n'));

var devWebPackConfig = defaultConfig.dev;
devWebPackConfig.resolve.alias = {
  "@app/env": path.resolve('./src/environments/environment.' + env + '.ts')
};

var prodWebPackConfig = defaultConfig.prod;
prodWebPackConfig.resolve.alias = {
  "@app/env": path.resolve('./src/environments/environment.' + env + '.ts')
};

module.exports = {
  dev: devWebPackConfig,
  prod: prodWebPackConfig
};


